<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class People extends Model
{
    public function addPerson($data){
        return $result = $this->insert($data);
        
    }
    
    public function searchPerson(){
        
    }
}
